import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes} from '@angular/router';
import { LoggedInGuardGuard } from '../logged-in-guard.guard';
import { SavedCheckGuard } from '../saved-check.guard';
import { SearchComponent } from '../search/search.component';
import { ItemComponent } from '../item/item.component';
import { HomeComponent } from '../home/home.component';

const appRoutes: Routes = [
  {path: '', component : HomeComponent},
  {path: 'search', component: SearchComponent,
  canDeactivate: [SavedCheckGuard]},
  {path: 'loggedinsearch', component: SearchComponent, canActivate: [LoggedInGuardGuard]},
  {path: 'item/:id', component: ItemComponent},
  {path: '**', redirectTo: '/'}

]

@NgModule({
  imports: [
    CommonModule, RouterModule.forRoot(appRoutes)
  ],
  exports: [RouterModule],
  declarations: []
})

export class AppRoutingModule { }