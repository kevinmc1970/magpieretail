import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CoreModule} from './core/core.module';
import { AppComponent } from './app.component';

// this is the root module as it imports BrowserModule
// all other modules are feature modules
// it also bootstraps the root component
// it declares the components it 'owns'/'controls' (the feature modules declare their own)
// it imports what it is dependent on to work
// every other module imports CommonModule (features)
// the forRoot says that the SharedModule instance is created here in the root
@NgModule({
  imports:      [ BrowserModule, CoreModule],
  declarations: [ AppComponent],
  bootstrap:    [ AppComponent ],
  providers: []
})
export class AppModule { }