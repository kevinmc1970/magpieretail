import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { EbayItem } from './ebay-item';

@Injectable({
  providedIn: 'root'
})
export class SearchServiceService {
  ebayCategories = "categoryId(1)=11700&categoryId(2)=11450&categoryId(3)=2984"
  url = 'https://svcs.ebay.com/services/search/FindingService/v1?OPERATION-NAME=findItemsByCategory&SERVICE-VERSION=1.0.0&SECURITY-APPNAME=KevinMcI-magpiesr-PRD-bf8fc7c73-aeffc832&GLOBAL-ID=EBAY-GB&RESPONSE-DATA-FORMAT=JSON&callback=JSONP_CALLBACK&REST-PAYLOAD&' + this.ebayCategories + '&paginationInput.entriesPerPage=300&itemFilter.name=Seller&itemFilter.value=magpieretail1';
  items = [];
  carouselHidden = false;
  constructor(private http: HttpClient) {
  }

  // the subscribe is getting the json - we dont need to pipe or map
  // Responses etc
  getEbayItems() {
    console.log("search service - getEbayItems()");
    return this.http.jsonp(this.url, 'callback');
  }

  processData(json: Object) {
    let searchResultItems = json.findItemsByCategoryResponse[0].searchResult[0].item;
    for (let item of searchResultItems) {
      let ebayItem = new EbayItem(item.itemId[0], item.title[0], item.galleryURL[0].replace("http:", "https:"), item.viewItemURL[0], item.sellingStatus[0].currentPrice[0].__value__,
        item.condition[0].conditionDisplayName[0],
        item.shippingInfo[0].shippingServiceCost[0].__value__);
      this.items.push(ebayItem);
    }
    return this.items;
  }

  getItem(id: string): EbayItem {
    return this.items.find(x => x.itemId === id);
  }

}