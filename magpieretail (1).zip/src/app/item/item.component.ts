import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SearchServiceService } from '../search-service.service';
import { EbayItem } from '../ebay-item';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {
  @Input() item: EbayItem;

  constructor(private route: ActivatedRoute, private searchService: SearchServiceService) { }

  ngOnInit() {
    this.item = new EbayItem();
    if (this.searchService.items.length == 0) {
      this.searchService.getEbayItems()
        .subscribe(json => this.processData(json));
    } else {
      this.route.params.subscribe(parameters => {
        this.item = this.searchService.getItem(parameters['id'])
      });
    }
  }

  processData(json: Object) {
    this.searchService.processData(json);
    this.route.params.subscribe(parameters => {
      this.item = this.searchService.getItem(parameters['id'])
    });
  }

  gotoUrl() {
    window.open(this.item.url, "_blank");
  }
}