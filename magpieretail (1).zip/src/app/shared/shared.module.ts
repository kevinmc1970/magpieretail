import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchServiceService } from '../search-service.service';
import { SharedComponent } from './shared.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [SharedComponent],
  exports: [SharedComponent]

})
export class SharedModule {
  // this is a way to make the shared module (and therefore the service too) a singleton created in the root only so anything lazy-loaded wont create their own instance
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      // provider is for services - at present this SharedModule only providing this service - services not owned my any module so dont really need to import SharedModule anywhere to use the service!
      providers: [SearchServiceService]
    };
  }
 }