export class EbayItem {

  constructor(public itemId?: string, 
  public title?: string,
  public image?: string, 
  public url?: string, 
  public currentPrice?: string,
  public condition?: string,
  public postage?: string) {

  }
}