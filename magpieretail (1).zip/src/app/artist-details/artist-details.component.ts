import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-artist-details',
  templateUrl: './artist-details.component.html',
  styleUrls: ['./artist-details.component.css']
})
export class ArtistDetailsComponent implements OnInit {
  artists: object;
  artist: object;

//note that adding variables to the contructor automatically creates them as properties in the component object i.e. route can be accessed with 'this.route' (this is a typescript thing)
  constructor(private route: ActivatedRoute) { 
    // would normally put this data in a service.ts and import where needed but duplicating here for convenience in this test
    this.artists = [
      {
        "id": 0,
        "name": "Barot Bellingham",
        "reknown": "School of Art",
        "bio": "blah blah school blah blah art"
      },
      {
        "id": 1,
        "name": "Hillary Hilton",
        "reknown": "New York University",
        "bio": "waffle new waffle yor waffle"
      }
    ]

    // can get the id value from the URL this way
    // this.artist = this.artists[this.route.snapshot.paramMap.get('id')];
  }

  ngOnInit() {
    // or get the id value this way
    this.route.params.subscribe(parameters => {
      this.artist = this.artists[parameters['id']];
    });
  }

}