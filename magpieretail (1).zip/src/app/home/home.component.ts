import { Component, OnInit } from '@angular/core';
import { SearchServiceService } from '../search-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

// Do I really need a Home Component? Should I just use AppComponent? Only done this because it made the app module very light (just bootstraps app) and imports CoreModule
// this component really just for routing purpose and unhiding the carousel
    constructor(private searchService: SearchServiceService) {
  }

//this is only hit when component called i.e. via routing
  ngOnInit() {
    this.searchService.carouselHidden = false;
  }

}