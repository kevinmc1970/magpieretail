import { Injectable } from '@angular/core';
import { CanDeactivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import {SearchComponent} from '../search/SearchComponent';

@Injectable()
export class SavedCheckGuard implements CanDeactivate<SearchComponent> {
  canDeactivate(
    component: SearchComponent,
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return component.isSaved();
  }
}
