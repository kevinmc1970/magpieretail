import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { CarouselComponent } from '../carousel/carousel.component'
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HomeComponent } from '../home/home.component';

import { ReactiveFormsModule, FormsModule, Validators } from '@angular/forms';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { SearchModule }  from '../search/search.module';
import { SharedModule } from '../shared/shared.module';
// these need to be here - don't work in search service
import {
  HttpClientJsonpModule,
  HttpClientModule
} from "@angular/common/http";
import { AppRoutingModule } from '../app-routing/app-routing.module'

// this module acting as the 'root' now - root just bootstraps
// all declared components are available to the other components owned by this module (or directly in templates too)
// providers is for services used (see SharedModue)

@NgModule({
  imports: [
    CommonModule, RouterModule, NgbModule.forRoot(), FormsModule, ReactiveFormsModule, SearchModule, HttpClientJsonpModule, AppRoutingModule, HttpClientModule, SharedModule.forRoot(), 
  ],
  declarations: [HomeComponent, HeaderComponent, CarouselComponent, FooterComponent],
  // export these Components so that app.component.html can call <app-home> etc
  exports: [HomeComponent, HeaderComponent, FooterComponent, CarouselComponent, RouterModule]
})
export class CoreModule { }