import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  //reactive forms - this 'model' not needed in template as all the binding and work done here
  model = { "search": "type here" };
  quickSearchForm = new FormGroup({
    // assign the formControlName in formGroup in the template called search. can also set default value
    // don't set validation in template (but can if want)
    search: new FormControl('default', Validators.required)
  });

  constructor(private router: Router) {
  }

  ngOnInit() {
    // force any first time visit i.e. bookmark to go to home page
    this.router.navigate(['']);

  }

  // this shows another way to handle routing - the button simply     calls this function and it changes the route. Needed the Router     import
  searchRedirect() {
    this.router.navigate(['/search']);
  }

  quickSearch() {
    // get this value from the form control - N.B. 'controls'
    console.log(this.quickSearchForm.controls.search.value);
    this.model.search = this.quickSearchForm.controls.search.value;
    console.log(this.model.search);
    this.router.navigate(['/search']);
  }

}
