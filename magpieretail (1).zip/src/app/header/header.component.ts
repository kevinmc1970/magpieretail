import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  public isCollapsed = true;

  constructor() { }

  ngOnInit() {
  }

  gotoUrl() {
    window.open('https://www.ebay.co.uk/sch/magpieretail1/m.html?_nkw=&_armrs=1&_ipg=&_from=', "_blank");
  }
}