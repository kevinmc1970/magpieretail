import { Component, OnInit } from '@angular/core';
import { SearchServiceService } from '../search-service.service';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.css'],
  providers: [NgbCarouselConfig]
})
export class CarouselComponent implements OnInit {
  // items is empty when component first loaded
  items = [{}];

  constructor(private config: NgbCarouselConfig, private searchService: SearchServiceService, private router: Router) { }

  ngOnInit() {
    console.log("carousel.component.ts ngOnIint called");

    // customize default values of carousels used by this component tree
    this.config.interval = 3000;
    this.config.wrap = false;
    this.config.keyboard = false;
    this.config.pauseOnHover = false;
    // this.config.showNavigationArrows = false;
    this.config.showNavigationIndicators = false;
    this.items = this.searchService.items;
    if (this.searchService.items.length == 0) {
      this.searchService.getEbayItems()
        .subscribe(json => this.processData(json));
    }
  }

  processData(json: Object) {
    this.items = this.searchService.processData(json);
  }

  showDetails(id) {
    this.router.navigate(['/item', id]);
  }

}