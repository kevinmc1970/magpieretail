import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes} from '@angular/router';
import { SearchComponent } from './search.component';
import { LoggedInGuardGuard } from '../logged-in-guard.guard';
import { SavedCheckGuard } from '../saved-check.guard';
// notice that the pipe does not have to be imported into the component - it can just be used in the html because it is declared here
import { SearchItemsPipe } from '../search-items.pipe';
import { ItemComponent } from '../item/item.component';
import { ArtistItemsComponent } from '../artist-items/artist-items.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
// could not get the 'proper' angular fontawesome to work but found this on another stackblitz and copied (https://stackblitz.com/edit/angular-fontawesome-test?file=src%2Fapp%2Fapp.module.ts)
// note that dont need to add anything to angular.json
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { library } from '@fortawesome/fontawesome-svg-core';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
// just add icons required - rather than download all of them I assume
library.add(faSearch);

@NgModule({
  imports: [
    CommonModule, FormsModule, SharedModule, FontAwesomeModule
  ],
  //anything provided not owned by this module and availble everywhere
  providers: [LoggedInGuardGuard, SavedCheckGuard ],
  declarations: [SearchComponent, ArtistItemsComponent, ItemComponent, SearchItemsPipe],
  exports: [ArtistItemsComponent, SearchComponent, ItemComponent]

// exports used if another module requires a component belonging to this module i.e. carousel.component might need so use artist-items component too - exports: [ArtistItemsComponent]
})
export class SearchModule { }