import { Component, OnInit, Input } from '@angular/core';
import { SearchServiceService } from '../search-service.service';
import { NgForm } from '@angular/forms';
import { EbayItem } from '../ebay-item';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  @Input() search: string;
  items = [];
  currentArtist: object;

  //N.B. don't need to import shared module or service into the module to use it here
  constructor(private searchService: SearchServiceService, private router: Router) {
  }

  ngOnInit() {
    this.searchService.carouselHidden = true;
    this.items = this.searchService.items;
    if (this.searchService.items.length == 0) {
      this.searchService.getEbayItems()
        .subscribe(json => this.processData(json));
    }
    // pipes are pure which means they only run when primitive input changes and therefore efficient so forcing change here to make results appear before input
    this.search = '';
  }

  processData(json: Object) {
    this.items = this.searchService.processData(json);
    // this pipe reset because items only just populated 
    this.search = '';
  }

  isSaved() {
    //simulate item being saved or not
    return true;
  }

  showDetails(id) {
    this.router.navigate(['/item', id]);
  }

}